document.write("<h1>Estadisticas Centro Médico Ñuñoa </h1>")

var radiologia = [
    { hora: "11:00", especialista: "Ignacion Schulz", paciente: "Francisca Rojas", rut: "9878782-1", prevision: "Fonasa" },
    { hora: "11:30", especialista: "Federico Subercaseaux", paciente: "Pamela Estrada", rut: "15345241-3", prevision: "Isapre" },
    { hora: "15:00", especialista: "Fernando Wurthz", paciente: "Armando Luna", rut: "16445345-9", prevision: "Isapre" },
    { hora: "15:30", especialista: "Ana Maria Godoy", paciente: "Manuel Godoy", rut: "17666419-0", prevision: "Fonasa" },
    { hora: "16:00", especialista: "Patricia Suazo", paciente: "Ramon Ulloa", rut: "14989389-K", prevision: "Fonasa" },
]

var traumatologia = [
    { hora: "08:00", especialidad: "Maria Paz Altuzarra", paciente: "Paula Sanchez", rut: "15554774-5", prevision: "Fonasa" },
    { hora: "10:00", especialidad: "Raul Araya", paciente: "Angélica Vavas", rut: "15444147-9", prevision: "Isapre" },
    { hora: "10:30", especialidad: "Maria Arriagada", paciente: "Ana Klapp", rut: "17879423-9", prevision: "Isapre" },
    { hora: "11:00", especialidad: "Alejandro Badilla", paciente: "Felipe Mardones", rut: "1547423-6", prevision: "Isapre" },
    { hora: "11:30", especialidad: "Cecilia Budnik", paciente: "Diego Marre", rut: "16554741-K", prevision: "Fonasa" },
    { hora: "12:00", especialidad: "Arturo Cavagnaro", paciente: "Cecilia Mendez", rut: "9747535-8", prevision: "Isapre" },
    { hora: "12:30", especialidad: "Andres Kanacri", paciente: "Marcial Suazo", rut: "11254785-5", prevision: "Isapre" },
]

var dental = [
    { hora: "08:30", especialidad: "Andrea Zuñiga", paciente: "Marcela Retamal", rut: "11123425-6", prevision: "Isapre" },
    { hora: "11:00", especialidad: "Maria Pia Zañartu", paciente: "Angel Muñoz", rut: "9878789-2", prevision: "Isapre" },
    { hora: "11:30", especialidad: "Scarlett Witting", paciente: "Mario Kast", rut: "7998789-5", prevision: "Fonasa" },
    { hora: "13:00", especialidad: "Francisco Von Teuber", paciente: "Karin Fernandez", rut: "18887662-K", prevision: "Fonasa" },
    { hora: "13:30", especialidad: "Eduardo Viñuela", paciente: "Hugo Sanchez", rut: "17665461-4", prevision: "Fonasa" },
    { hora: "14:00", especialidad: "Raquel Villaseca", paciente: "Ana Sepulveda", rut: "14441281-0", prevision: "Isapre" },
]


document.write("<h2>Atenciones</h2>");
document.write("<h4>Cantidad de atenciones para traumatologia fue:" + radiologia.length);
document.write("<h4>Cantidad de Atenciones para Traumatología fue:" + traumatologia.length);
document.write("<h4>Cantidad de Atenciones para dental fue:" + dental.length);



document.write("<h3>Radiología:</h3>") +
    document.write("Primera Atención:" + radiologia[0].paciente + " - " + "RUT:" + radiologia[0].rut + " - " + radiologia[0].prevision + " | " + "Ultima Atención:" + radiologia[4].paciente + " - " + "RUT:" + radiologia[4].rut + " - " + radiologia[4].prevision)

document.write("<h3>Traumatología:</h3>") +
    document.write("Primera Atención:" + traumatologia[0].paciente + " - " + "RUT:" + traumatologia[0].rut + " - " + traumatologia[0].prevision + " | " + "Ultima Atención:" + traumatologia[6].paciente + " - " + "RUT:" + traumatologia[6].rut + " - " + traumatologia[6].prevision)

document.write("<h3>Dental:</h3>") +
    document.write("Primera Atención:" + dental[0].paciente + " - " + "RUT:" + dental[0].rut + " - " + dental[0].prevision + " | " + "Ultima Atención:" + dental[5].paciente + " - " + "RUT:" + dental[5].rut + " - " + dental[5].prevision)